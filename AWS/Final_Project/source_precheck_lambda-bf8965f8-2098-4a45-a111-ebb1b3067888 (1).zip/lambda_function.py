import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Any, List

import boto3
from botocore.exceptions import ClientError


logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")


REQUIRED_SOURCES = {
    "orders": {
        "prefix_key": "raw_orders_prefix",
        "allowed_extensions": [".csv"],
        "min_file_size_bytes": 10
    },
    "clickstream": {
        "prefix_key": "raw_clickstream_prefix",
        "allowed_extensions": [".json"],
        "min_file_size_bytes": 10
    },
    "catalog": {
        "prefix_key": "raw_catalog_prefix",
        "allowed_extensions": [".csv", ".json"],
        "min_file_size_bytes": 10
    },
    "fx_rates": {
        "prefix_key": "raw_fx_rates_prefix",
        "allowed_extensions": [".json"],
        "min_file_size_bytes": 10
    },
    "shipping_zone": {
        "prefix_key": "raw_shipping_zone_prefix",
        "allowed_extensions": [".json"],
        "min_file_size_bytes": 10
    },
    "holidays": {
        "prefix_key": "raw_holidays_prefix",
        "allowed_extensions": [".json"],
        "min_file_size_bytes": 10
    }
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_config(event: Dict[str, Any]) -> Dict[str, Any]:
    config = event.get("config")
    print(config)

    if not config:
        raise ValueError("Missing config object from previous Lambda")

    if not isinstance(config, dict):
        raise ValueError("Config must be a JSON object")

    if not config.get("bucket_name"):
        raise ValueError("Missing bucket_name in config")

    return config


def list_s3_objects(bucket: str, prefix: str) -> List[Dict[str, Any]]:
    objects = []
    continuation_token = None

    while True:
        params = {
            "Bucket": bucket,
            "Prefix": prefix
        }

        if continuation_token:
            params["ContinuationToken"] = continuation_token

        response = s3.list_objects_v2(**params)

        objects.extend(response.get("Contents", []))

        if not response.get("IsTruncated"):
            break

        continuation_token = response.get("NextContinuationToken")

    return objects


def is_folder_placeholder(key: str, size: int) -> bool:
    return key.endswith("/") and size == 0


def is_valid_extension(key: str, allowed_extensions: List[str]) -> bool:
    key_lower = key.lower()
    return any(key_lower.endswith(ext) for ext in allowed_extensions)


def validate_source_files(
    bucket: str,
    source_name: str,
    prefix: str,
    allowed_extensions: List[str],
    min_file_size_bytes: int
) -> Dict[str, Any]:

    logger.info("Validating source=%s prefix=%s", source_name, prefix)

    objects = list_s3_objects(bucket, prefix)

    valid_files = []
    invalid_files = []
    file_names_seen = set()
    duplicate_files = []

    for obj in objects:
        key = obj["Key"]
        size = obj["Size"]
        last_modified = obj["LastModified"].isoformat()

        if is_folder_placeholder(key, size):
            continue

        file_name = key.split("/")[-1]

        if file_name in file_names_seen:
            duplicate_files.append(key)
        else:
            file_names_seen.add(file_name)

        if size == 0:
            invalid_files.append({
                "key": key,
                "reason": "ZERO_BYTE_FILE",
                "size": size,
                "last_modified": last_modified
            })
            continue

        if size < min_file_size_bytes:
            invalid_files.append({
                "key": key,
                "reason": "FILE_TOO_SMALL",
                "size": size,
                "last_modified": last_modified
            })
            continue

        if not is_valid_extension(key, allowed_extensions):
            invalid_files.append({
                "key": key,
                "reason": "INVALID_FILE_EXTENSION",
                "allowed_extensions": allowed_extensions,
                "size": size,
                "last_modified": last_modified
            })
            continue

        valid_files.append({
            "key": key,
            "file_name": file_name,
            "size": size,
            "last_modified": last_modified
        })

    source_status = "SUCCESS"

    if len(valid_files) == 0:
        source_status = "FAILED"

    if invalid_files:
        source_status = "FAILED"

    if duplicate_files:
        source_status = "FAILED"

    return {
        "source_name": source_name,
        "prefix": prefix,
        "status": source_status,
        "valid_file_count": len(valid_files),
        "invalid_file_count": len(invalid_files),
        "duplicate_file_count": len(duplicate_files),
        "valid_files": valid_files,
        "invalid_files": invalid_files,
        "duplicate_files": duplicate_files
    }


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    logger.info("source_precheck_lambda started")
    logger.info("Received event: %s", json.dumps(event))

    try:
        config = get_config(event)
        bucket = config["bucket_name"]

        source_results = {}
        failed_sources = []

        for source_name, rules in REQUIRED_SOURCES.items():
            prefix_key = rules["prefix_key"]
            prefix = config.get(prefix_key)

            if not prefix:
                failed_sources.append(source_name)
                source_results[source_name] = {
                    "source_name": source_name,
                    "status": "FAILED",
                    "reason": f"Missing prefix config key: {prefix_key}"
                }
                continue

            result = validate_source_files(
                bucket=bucket,
                source_name=source_name,
                prefix=prefix,
                allowed_extensions=rules["allowed_extensions"],
                min_file_size_bytes=rules["min_file_size_bytes"]
            )

            source_results[source_name] = result

            if result["status"] != "SUCCESS":
                failed_sources.append(source_name)

        if failed_sources:
            logger.error("Source validation failed for: %s", failed_sources)

            return {
                "statusCode": 500,
                "validation_status": "FAILED",
                "message": "One or more source validations failed",
                "bucket": bucket,
                "failed_sources": failed_sources,
                "source_results": source_results,
                "checked_at": utc_now()
            }

        logger.info("All source validations passed")

        return {
            "statusCode": 200,
            "validation_status": "SUCCESS",
            "message": "All source files are available and valid",
            "bucket": bucket,
            "source_results": source_results,
            "checked_at": utc_now()
        }

    except ClientError as e:
        logger.exception("AWS client error in source_precheck_lambda")

        return {
            "statusCode": 500,
            "validation_status": "ERROR",
            "message": "AWS client error during source validation",
            "error": str(e),
            "checked_at": utc_now()
        }

    except Exception as e:
        logger.exception("Unexpected error in source_precheck_lambda")

        return {
            "statusCode": 500,
            "validation_status": "ERROR",
            "message": "Unexpected error during source validation",
            "error": str(e),
            "checked_at": utc_now()
        }