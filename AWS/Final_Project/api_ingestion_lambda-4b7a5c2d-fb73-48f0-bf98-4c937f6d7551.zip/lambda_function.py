import json
import logging
import hashlib
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Dict, Any

import boto3
from botocore.exceptions import ClientError


logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")

REQUEST_TIMEOUT_SECONDS = 15


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def generate_checksum(payload: Dict[str, Any]) -> str:
    payload_string = json.dumps(payload, sort_keys=True)
    return hashlib.md5(payload_string.encode("utf-8")).hexdigest()


def validate_api_response(response_json: Dict[str, Any], api_name: str):
    if not response_json:
        raise ValueError(f"{api_name} API returned empty response")

    if not isinstance(response_json, dict):
        raise ValueError(f"{api_name} API response is not a JSON object")


def upload_json_to_s3(bucket: str, key: str, payload: Dict[str, Any]):
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(payload, indent=2).encode("utf-8"),
        ContentType="application/json"
    )


def check_existing_checksum(bucket: str, checksum_key: str, current_checksum: str) -> bool:
    try:
        response = s3.get_object(Bucket=bucket, Key=checksum_key)
        previous_checksum = response["Body"].read().decode("utf-8").strip()
        return previous_checksum == current_checksum

    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code")

        if error_code in ["NoSuchKey", "404", "NotFound"]:
            return False

        raise


def update_checksum(bucket: str, checksum_key: str, checksum_value: str):
    s3.put_object(
        Bucket=bucket,
        Key=checksum_key,
        Body=checksum_value.encode("utf-8"),
        ContentType="text/plain"
    )


def fetch_json_with_retry(url: str, api_name: str, max_retries: int = 3) -> Dict[str, Any]:
    last_error = None

    for attempt in range(1, max_retries + 1):
        try:
            logger.info("Calling %s API. Attempt %s of %s", api_name, attempt, max_retries)

            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "aws-lambda-ecommerce-pipeline/1.0"
                }
            )

            with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
                status_code = response.getcode()

                if status_code == 429:
                    raise RuntimeError(f"{api_name} API rate limit exceeded")

                if status_code < 200 or status_code >= 300:
                    raise RuntimeError(f"{api_name} API returned status code {status_code}")

                response_body = response.read().decode("utf-8")
                data = json.loads(response_body)

                validate_api_response(data, api_name)

                return data

        except urllib.error.HTTPError as e:
            last_error = e

            if e.code == 429:
                logger.warning("%s API rate limited. Attempt %s", api_name, attempt)
            else:
                logger.warning("%s API HTTP error: %s", api_name, str(e))

            if attempt == max_retries:
                raise

            time.sleep(2 ** attempt)

        except urllib.error.URLError as e:
            last_error = e
            logger.warning("%s API URL error: %s", api_name, str(e))

            if attempt == max_retries:
                raise

            time.sleep(2 ** attempt)

        except Exception as e:
            last_error = e
            logger.warning("%s API call failed: %s", api_name, str(e))

            if attempt == max_retries:
                raise

            time.sleep(2 ** attempt)

    raise RuntimeError(f"{api_name} API failed after retries: {str(last_error)}")


def fetch_fx_rates_api() -> Dict[str, Any]:
    url = "https://open.er-api.com/v6/latest/USD"
    return fetch_json_with_retry(url=url, api_name="FX_RATES")


def fetch_shipping_zone_data() -> Dict[str, Any]:
    return {
        "generated_at": utc_now_iso(),
        "shipping_zones": [
            {"country": "India", "zone": "APAC", "delivery_days": 5},
            {"country": "USA", "zone": "NA", "delivery_days": 3},
            {"country": "Germany", "zone": "EU", "delivery_days": 4},
            {"country": "UK", "zone": "EU", "delivery_days": 4},
            {"country": "Canada", "zone": "NA", "delivery_days": 5}
        ]
    }


def fetch_holiday_data() -> Dict[str, Any]:
    return {
        "generated_at": utc_now_iso(),
        "holidays": [
            {"country": "India", "holiday_name": "Republic Day", "holiday_date": "2026-01-26"},
            {"country": "India", "holiday_name": "Independence Day", "holiday_date": "2026-08-15"},
            {"country": "India", "holiday_name": "Diwali", "holiday_date": "2026-11-08"},
            {"country": "USA", "holiday_name": "Thanksgiving", "holiday_date": "2026-11-26"},
            {"country": "Global", "holiday_name": "Christmas", "holiday_date": "2026-12-25"}
        ]
    }


def process_api_payload(bucket: str, prefix: str, file_prefix: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    checksum = generate_checksum(payload)
    checksum_key = f"{prefix}checksum/latest_checksum.txt"

    if check_existing_checksum(bucket, checksum_key, checksum):
        logger.info("%s payload unchanged. Skipping upload.", file_prefix)
        return {
            "status": "SKIPPED",
            "reason": "DUPLICATE_CHECKSUM",
            "checksum_key": checksum_key
        }

    file_key = f"{prefix}{file_prefix}_{utc_timestamp()}.json"

    upload_json_to_s3(bucket, file_key, payload)
    update_checksum(bucket, checksum_key, checksum)

    logger.info("%s uploaded to %s", file_prefix, file_key)

    return {
        "status": "UPLOADED",
        "file_key": file_key,
        "checksum_key": checksum_key
    }


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    start_time = time.time()

    logger.info("api_ingestion_lambda started")
    logger.info("Received event: %s", json.dumps(event))

    try:
        config = event.get("config")

        if not config:
            raise ValueError("Missing config object")

        bucket = config["bucket_name"]

        results = {}

        if config.get("fx_api_enabled", False):
            fx_payload = fetch_fx_rates_api()
            results["fx_rates"] = process_api_payload(
                bucket=bucket,
                prefix=config["raw_fx_rates_prefix"],
                file_prefix="fx_rates",
                payload=fx_payload
            )

        if config.get("shipping_api_enabled", False):
            shipping_payload = fetch_shipping_zone_data()
            results["shipping_zone"] = process_api_payload(
                bucket=bucket,
                prefix=config["raw_shipping_zone_prefix"],
                file_prefix="shipping_zone",
                payload=shipping_payload
            )

        if config.get("holiday_api_enabled", False):
            holiday_payload = fetch_holiday_data()
            results["holidays"] = process_api_payload(
                bucket=bucket,
                prefix=config["raw_holidays_prefix"],
                file_prefix="holidays",
                payload=holiday_payload
            )

        uploaded_files = [
            value["file_key"]
            for value in results.values()
            if value.get("status") == "UPLOADED"
        ]

        return {
            "statusCode": 200,
            "ingestion_status": "SUCCESS",
            "message": "API ingestion completed successfully",
            "results": results,
            "uploaded_files": uploaded_files,
            "runtime_seconds": round(time.time() - start_time, 2),
            "processed_at": utc_now_iso()
        }

    except Exception as e:
        logger.exception("Error in api_ingestion_lambda")

        return {
            "statusCode": 500,
            "ingestion_status": "FAILED",
            "message": "API ingestion failed",
            "error": str(e),
            "runtime_seconds": round(time.time() - start_time, 2),
            "processed_at": utc_now_iso()
        }