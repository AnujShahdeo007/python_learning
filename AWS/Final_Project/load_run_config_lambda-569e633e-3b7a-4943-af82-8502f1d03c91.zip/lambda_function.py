import json
import os
import boto3

"""
This Lambda is the first control step of the pipeline.

It reads the pipeline configuration file from S3 and returns it to Step Functions,
so the rest of the workflow knows:
- which bucket to use
- where raw data is located
- where processed data should go
- where curated data should go
- whether APIs are enabled
- which crawler to run
- which Athena output bucket to use
"""


def validate_config(config):
    required_keys = [
        "run_date",
        "environment",
        "reporting_currency",
        "bucket_name",
        "raw_orders_prefix",
        "raw_clickstream_prefix",
        "raw_catalog_prefix",
        "processed_orders_prefix",
        "processed_clickstream_prefix",
        "processed_catalog_prefix",
        "curated_customer_360_prefix",
        "curated_revenue_summary_prefix",
        "crawler_name",
        "glue_database",
        "athena_output_bucket",
        "athena_output_prefix"
    ]

    missing = [key for key in required_keys if key not in config]

    if missing:
        raise ValueError(f"Missing required keys in config: {missing}")


def lambda_handler(event, context):
    bucket = os.environ.get("CONFIG_BUCKET")
    key = os.environ.get("CONFIG_KEY")

    if not bucket or not key:
        raise ValueError("CONFIG_BUCKET and CONFIG_KEY environment variables are required")

    print(f"Reading config from s3://{bucket}/{key}")

    s3 = boto3.client("s3")
    response = s3.get_object(Bucket=bucket, Key=key)

    content = response["Body"].read().decode("utf-8")
    config = json.loads(content)

    print("Validating config values")
    validate_config(config)

    print("Config loaded successfully")

    return {
        "statusCode": 200,
        "message": "Config loaded successfully",
        "config": config
    }