import json
import os
import boto3
import urllib.parse
from datetime import datetime

# AWS clients
s3_client = boto3.client("s3")
sns_client = boto3.client("sns")

# Environment variables
BUCKET_NAME = "smart-city-weather-monitoring"
SNS_TOPIC_ARN = "arn:aws:sns:us-west-1:603601475895:smartcity-weather-alert-topic"
TEMP_THRESHOLD = float(os.environ.get("TEMP_THRESHOLD", "25"))
RAIN_THRESHOLD = float(os.environ.get("RAIN_THRESHOLD", "1"))
WIND_THRESHOLD = float(os.environ.get("WIND_THRESHOLD", "10"))


def lambda_handler(event, context):
    """
    Alert Lambda:
    1. Triggered by S3 when processed file is created
    2. Reads processed weather JSON
    3. Checks thresholds
    4. Publishes SNS alert if needed
    """

    print("Weather Alert Lambda started")
    print(f"Received event: {json.dumps(event)}")

    try:
        record = event["Records"][0]
        bucket_name = record["s3"]["bucket"]["name"]
        processed_key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])

        print(f"Bucket name from event: {bucket_name}")
        print(f"Processed S3 key from event: {processed_key}")

        # Read processed file from S3
        response = s3_client.get_object(Bucket=bucket_name, Key=processed_key)
        processed_content = response["Body"].read().decode("utf-8")
        processed_data = json.loads(processed_content)

        print("Processed file successfully read from S3")

        metadata = processed_data.get("metadata", {})
        summary = processed_data.get("summary", {})

        city = metadata.get("city", "unknown")
        processed_at = metadata.get("processed_at", "")
        raw_s3_key = metadata.get("raw_s3_key", "")

        max_temperature = summary.get("max_temperature")
        max_rain = summary.get("max_rain")
        max_wind_speed = summary.get("max_wind_speed")
        record_count = summary.get("record_count", 0)

        alerts = []

        if max_temperature is not None and float(max_temperature) > TEMP_THRESHOLD:
            alerts.append(
                f"High temperature detected in {city}: {max_temperature}°C exceeds threshold {TEMP_THRESHOLD}°C"
            )

        if max_rain is not None and float(max_rain) > RAIN_THRESHOLD:
            alerts.append(
                f"Heavy rainfall detected in {city}: {max_rain} mm exceeds threshold {RAIN_THRESHOLD} mm"
            )

        if max_wind_speed is not None and float(max_wind_speed) > WIND_THRESHOLD:
            alerts.append(
                f"High wind speed detected in {city}: {max_wind_speed} km/h exceeds threshold {WIND_THRESHOLD} km/h"
            )

        if alerts:
            subject = f"Weather Alert for {city}"

            message = {
                "alert_type": "weather_threshold_breach",
                "city": city,
                "processed_at": processed_at,
                "record_count": record_count,
                "processed_s3_key": processed_key,
                "raw_s3_key": raw_s3_key,
                "thresholds": {
                    "temperature_threshold": TEMP_THRESHOLD,
                    "rain_threshold": RAIN_THRESHOLD,
                    "wind_threshold": WIND_THRESHOLD
                },
                "breaches": alerts,
                "alert_generated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            }

            sns_response = sns_client.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject=subject,
                Message=json.dumps(message, indent=2)
            )

            print("SNS alert sent successfully")
            print(f"SNS Message ID: {sns_response['MessageId']}")

            return {
                "status": "success",
                "alert_sent": True,
                "city": city,
                "processed_s3_key": processed_key,
                "alerts": alerts,
                "sns_message_id": sns_response["MessageId"]
            }

        print(f"No alert needed for city: {city}")

        return {
            "status": "success",
            "alert_sent": False,
            "city": city,
            "processed_s3_key": processed_key,
            "message": "No threshold breach detected"
        }

    except Exception as e:
        error_message = f"Alert processing failed: {str(e)}"
        print(error_message)

        return {
            "status": "failed",
            "error_message": error_message
        }