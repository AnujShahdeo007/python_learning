import json
import os
import boto3
import urllib.parse
from datetime import datetime

# AWS client
s3_client = boto3.client("s3")

# Environment variables
BUCKET_NAME = "smart-city-weather-monitoring"
PROCESSED_PREFIX = "processed"
FAILED_PREFIX = "failed"


def safe_max(values):
    """
    Return max value from list if available, else None.
    """
    if isinstance(values, list) and values:
        return max(values)
    return None


def build_processed_key(raw_key, city):
    """
    Build processed S3 key from city and current timestamp.
    Example:
    processed/city=delhi/date=2026-04-10/weather_processed_20260410T151000Z.json
    """
    now = datetime.utcnow()
    date_part = now.strftime("%Y-%m-%d")
    timestamp_part = now.strftime("%Y%m%dT%H%M%SZ")
    city_clean = city.strip().lower().replace(" ", "_")

    return f"{PROCESSED_PREFIX}/city={city_clean}/date={date_part}/weather_processed_{timestamp_part}.json"


def build_failed_key(raw_key):
    """
    Build failed S3 key if processing fails.
    """
    now = datetime.utcnow()
    date_part = now.strftime("%Y-%m-%d")
    timestamp_part = now.strftime("%Y%m%dT%H%M%SZ")

    return f"{FAILED_PREFIX}/date={date_part}/processing_error_{timestamp_part}.json"


def lambda_handler(event, context):
    """
    Processor Lambda:
    1. Triggered by S3 raw file upload
    2. Reads raw JSON from S3
    3. Extracts useful weather fields
    4. Creates processed summary output
    5. Stores processed JSON in S3
    """

    print("Weather Processor Lambda started")
    print(f"Received event: {json.dumps(event)}")

    try:
        record = event["Records"][0]
        bucket_name = record["s3"]["bucket"]["name"]
        raw_key = urllib.parse.unquote_plus(record["s3"]["object"]["key"])

        print(f"Bucket name from event: {bucket_name}")
        print(f"Raw S3 key from event: {raw_key}")

        # Read raw object from S3
        response = s3_client.get_object(Bucket=bucket_name, Key=raw_key)
        raw_content = response["Body"].read().decode("utf-8")
        raw_data = json.loads(raw_content)

        print("Raw file successfully read from S3")

        metadata = raw_data.get("metadata", {})
        api_response = raw_data.get("api_response", {})
        hourly_data = api_response.get("hourly", {})

        city = metadata.get("city", "unknown")
        latitude = metadata.get("latitude")
        longitude = metadata.get("longitude")
        triggered_at = metadata.get("triggered_at")
        ingested_at = metadata.get("ingested_at")
        api_url = metadata.get("api_url")
        source = metadata.get("source")

        times = hourly_data.get("time", [])
        temperatures = hourly_data.get("temperature_2m", [])
        humidity_values = hourly_data.get("relative_humidity_2m", [])
        rain_values = hourly_data.get("rain", [])
        wind_values = hourly_data.get("wind_speed_10m", [])

        processed_payload = {
            "metadata": {
                "city": city,
                "latitude": latitude,
                "longitude": longitude,
                "source": source,
                "triggered_at": triggered_at,
                "ingested_at": ingested_at,
                "processed_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "raw_s3_key": raw_key,
                "api_url": api_url
            },
            "summary": {
                "record_count": len(times),
                "max_temperature": safe_max(temperatures),
                "max_relative_humidity": safe_max(humidity_values),
                "max_rain": safe_max(rain_values),
                "max_wind_speed": safe_max(wind_values)
            },
            "hourly_data": {
                "time": times,
                "temperature_2m": temperatures,
                "relative_humidity_2m": humidity_values,
                "rain": rain_values,
                "wind_speed_10m": wind_values
            }
        }

        processed_key = build_processed_key(raw_key, city)

        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=processed_key,
            Body=json.dumps(processed_payload),
            ContentType="application/json"
        )

        print(f"Processed file written successfully to S3")
        print(f"Processed S3 key: {processed_key}")

        final_response = {
            "message": "Weather data processed successfully",
            "bucket_name": BUCKET_NAME,
            "raw_s3_key": raw_key,
            "processed_s3_key": processed_key,
            "city": city,
            "status": "success"
        }

        print(f"Final response: {json.dumps(final_response)}")
        return final_response

    except Exception as e:
        error_message = f"Processing failed: {str(e)}"
        print(error_message)

        failed_payload = {
            "error_message": error_message,
            "received_event": event,
            "failed_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        }

        failed_key = build_failed_key("unknown")

        try:
            s3_client.put_object(
                Bucket=BUCKET_NAME,
                Key=failed_key,
                Body=json.dumps(failed_payload),
                ContentType="application/json"
            )
            print(f"Failure details written to S3: {failed_key}")
        except Exception as inner_error:
            print(f"Failed to write error payload to S3: {str(inner_error)}")

        return {
            "status": "failed",
            "error_message": error_message,
            "failed_s3_key": failed_key
        }