import json
import os
import boto3
from datetime import datetime

# Create Lambda client once, outside handler, for better performance
lambda_client = boto3.client("lambda")

# Read target Lambda name from environment variable
INGESTION_LAMBDA_NAME = "ingestion_orchestrator_lambda"

# List of cities we want to process
CITIES = [
    {"city": "Delhi", "latitude": 28.6139, "longitude": 77.2090},
    {"city": "Mumbai", "latitude": 19.0760, "longitude": 72.8777},
    {"city": "Bengaluru", "latitude": 12.9716, "longitude": 77.5946},
    {"city": "Hyderabad", "latitude": 17.3850, "longitude": 78.4867},
    {"city": "Chennai", "latitude": 13.0827, "longitude": 80.2707},
    {"city": "Kolkata", "latitude": 22.5726, "longitude": 88.3639},
    {"city": "Pune", "latitude": 18.5204, "longitude": 73.8567},
    {"city": "Ahmedabad", "latitude": 23.0225, "longitude": 72.5714},
    {"city": "Jaipur", "latitude": 26.9124, "longitude": 75.7873},
    {"city": "Lucknow", "latitude": 26.8467, "longitude": 80.9462},
    {"city": "Bhopal", "latitude": 23.2599, "longitude": 77.4126},
    {"city": "Patna", "latitude": 25.5941, "longitude": 85.1376},
    {"city": "Ranchi", "latitude": 23.3441, "longitude": 85.3096},
    {"city": "Bhubaneswar", "latitude": 20.2961, "longitude": 85.8245},
    {"city": "Guwahati", "latitude": 26.1445, "longitude": 91.7362}
]


def lambda_handler(event, context):
    """
    Controller Lambda:
    1. Runs on schedule or manual trigger
    2. Loops through city list
    3. Invokes ingestion Lambda asynchronously for each city
    """

    print("Controller Lambda started")
    print(f"Received event: {json.dumps(event)}")
    print(f"Target ingestion lambda: {INGESTION_LAMBDA_NAME}")

    results = []
    run_timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

    for city_data in CITIES:
        payload = {
            "city": city_data["city"],
            "latitude": city_data["latitude"],
            "longitude": city_data["longitude"],
            "triggered_at": run_timestamp,
            "source": "controller_lambda"
        }

        try:
            response = lambda_client.invoke(
                FunctionName=INGESTION_LAMBDA_NAME,
                InvocationType="Event",   # asynchronous invocation
                Payload=json.dumps(payload).encode("utf-8")
            )

            print(f"Successfully invoked ingestion lambda for {city_data['city']}")
            print(f"Invoke response: {response}")

            results.append({
                "city": city_data["city"],
                "status": "invoked",
                "status_code": response["StatusCode"]
            })

        except Exception as e:
            print(f"Error invoking ingestion lambda for {city_data['city']}: {str(e)}")

            results.append({
                "city": city_data["city"],
                "status": "failed",
                "error_message": str(e)
            })

    final_response = {
        "message": "Controller Lambda execution completed",
        "triggered_at": run_timestamp,
        "target_lambda": INGESTION_LAMBDA_NAME,
        "total_cities": len(CITIES),
        "results": results
    }

    print(f"Final response: {json.dumps(final_response)}")
    return final_response