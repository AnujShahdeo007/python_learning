import json
import os
import boto3
import urllib3
from datetime import datetime

# AWS clients
s3_client = boto3.client("s3")

# HTTP connection pool
http = urllib3.PoolManager()

# Environment variables
BUCKET_NAME = "smart-city-weather-monitoring"
RAW_PREFIX = "raw"
API_BASE_URL = "https://api.open-meteo.com/v1/forecast"


def build_api_url(latitude, longitude):
    """
    Build Open-Meteo API URL using latitude and longitude.
    """
    return (
        f"{API_BASE_URL}"
        f"?latitude={latitude}"
        f"&longitude={longitude}"
        f"&hourly=temperature_2m,relative_humidity_2m,rain,wind_speed_10m"
        f"&forecast_days=1"
    )


def build_s3_key(city):
    """
    Build S3 object key for raw weather data.
    Example:
    raw/city=delhi/date=2026-04-10/weather_20260410T150000Z.json
    """
    now = datetime.utcnow()
    date_part = now.strftime("%Y-%m-%d")
    timestamp_part = now.strftime("%Y%m%dT%H%M%SZ")
    city_clean = city.strip().lower().replace(" ", "_")

    return f"{RAW_PREFIX}/city={city_clean}/date={date_part}/weather_{timestamp_part}.json"


def lambda_handler(event, context):
    """
    Ingestion Lambda:
    1. Receive city payload from controller lambda
    2. Call Open-Meteo API
    3. Store raw JSON in S3
    """

    print("Ingestion Lambda started")
    print(f"Received event: {json.dumps(event)}")

    try:
        city = event["city"]
        latitude = event["latitude"]
        longitude = event["longitude"]
        triggered_at = event.get("triggered_at", "")
        source = event.get("source", "unknown")

        print(f"City: {city}")
        print(f"Latitude: {latitude}")
        print(f"Longitude: {longitude}")
        print(f"Triggered at: {triggered_at}")
        print(f"Source: {source}")

        api_url = build_api_url(latitude, longitude)
        print(f"Calling API URL: {api_url}")

        response = http.request("GET", api_url)
        status_code = response.status
        response_body = response.data.decode("utf-8")

        print(f"API response status code: {status_code}")

        if status_code != 200:
            raise Exception(f"API call failed with status code {status_code}")

        api_data = json.loads(response_body)

        s3_key = build_s3_key(city)

        raw_payload = {
            "metadata": {
                "city": city,
                "latitude": latitude,
                "longitude": longitude,
                "triggered_at": triggered_at,
                "source": source,
                "api_url": api_url,
                "ingested_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            },
            "api_response": api_data
        }

        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=s3_key,
            Body=json.dumps(raw_payload),
            ContentType="application/json"
        )

        print(f"Successfully stored raw API response in S3")
        print(f"Bucket: {BUCKET_NAME}")
        print(f"Key: {s3_key}")

        final_response = {
            "message": "Weather data ingested successfully",
            "city": city,
            "bucket_name": BUCKET_NAME,
            "raw_s3_key": s3_key,
            "api_status_code": status_code,
            "status": "success"
        }

        print(f"Final response: {json.dumps(final_response)}")
        return final_response

    except KeyError as e:
        error_message = f"Missing required field in event: {str(e)}"
        print(error_message)
        return {
            "status": "failed",
            "error_message": error_message
        }

    except Exception as e:
        error_message = f"Ingestion failed: {str(e)}"
        print(error_message)
        return {
            "status": "failed",
            "error_message": error_message
        }